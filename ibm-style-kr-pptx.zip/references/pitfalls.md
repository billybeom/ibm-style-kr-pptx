# QA 프로세스 및 일반적인 함정

## QA 프로세스

**문제가 있다고 가정하십시오. 당신의 역할은 그것을 찾아내는 것입니다.**

첫 번째 렌더링이 올바를 가능성은 거의 없습니다. QA를 확인 단계가 아닌 버그 사냥으로 접근하십시오. 첫 번째 검사에서 문제를 발견하지 못했다면 충분히 꼼꼼히 보지 않은 것입니다.

### IBM QA 체크리스트 (완료 선언 전 반드시 실행)

- [ ] **슬라이드 1은 커버** — 페이지 번호 없음, 대형 제목 좌측, 선택적 이미지 우측
- [ ] **마지막 슬라이드는 엔딩** — 페이지 번호 없음, IBM 브랜드 마무리
- [ ] **커버·엔딩 외 모든 슬라이드에 페이지 번호** (x=25.75" y=14.16")
- [ ] **모든 본문/레이블 텍스트는 28pt 이상** (표 본문에만 20pt 허용)
- [ ] **폰트 패밀리는 IBM Plex Sans KR** 전체 — Arial, Helvetica, Calibri 등 없음
- [ ] **이탤릭체 없음** — IBM Plex는 프레젠테이션에서 로만체만 사용
- [ ] **캔버스는 26.67" × 15.00"** — 표준 LAYOUT_16x9 아님
- [ ] **IBM 이외 색상 없음** — IBM Carbon 팔레트 색상만 사용
- [ ] **그라디언트 또는 애니메이션 없음**
- [ ] **제목 좌측 정렬** — 가운데 정렬 아님
- [ ] **콘텐츠는 x=0.63"에서 시작** — 일관된 좌측 여백
- [ ] **y=13.5" 아래에 콘텐츠 없음** — 푸터 영역 예약됨

### 콘텐츠 QA

```bash
python -m markitdown output.pptx
```

누락된 콘텐츠, 오타, 잘못된 순서를 확인하십시오.

**남은 플레이스홀더 텍스트 확인:**

```bash
python -m markitdown output.pptx | grep -iE "xxxx|lorem|ipsum|placeholder|this.*(page|slide).*layout"
```

grep 결과가 있으면 완료 선언 전에 수정하십시오.

### 검증 루프

1. 슬라이드 생성 → `python -m markitdown output.pptx`로 텍스트 추출 → 콘텐츠 검토
2. 위의 **IBM QA 체크리스트 실행** — 모든 항목 확인
3. **발견된 문제 목록 작성** (없다면 더 비판적으로 다시 확인)
4. 문제 수정
5. **영향받은 슬라이드 재검증** — 하나의 수정이 종종 다른 문제를 만듦
6. 새로운 문제 없이 전체 검사를 통과할 때까지 반복

**수정 및 재검증 사이클을 최소 한 번 완료하기 전까지 완료를 선언하지 마십시오.**

### 슬라이드별 QA (처음부터 생성 시)

```bash
python -m markitdown slide-XX-preview.pptx
```

누락된 콘텐츠, 플레이스홀더 텍스트, 누락된 페이지 번호를 확인하십시오.

---

## IBM 특화 실수 방지

- **커버 슬라이드를 빠뜨리지 마십시오** — 모든 IBM 덱은 커버 슬라이드로 시작 (페이지 번호 없음)
- **엔딩 슬라이드를 빠뜨리지 마십시오** — 모든 IBM 덱은 엔딩 슬라이드로 종료 (페이지 번호 없음)
- **페이지 번호를 잊지 마십시오** — 커버·엔딩 외 모든 슬라이드에 x=25.75" y=14.16" 위치에 필요
- **IBM Plex Sans KR 이외 폰트 사용 금지** — Arial, Helvetica, Calibri 또는 다른 패밀리 금지
- **이탤릭체 사용 금지** — IBM Plex는 IBM 프레젠테이션에서 로만체만 사용
- **28pt 이하 사용 금지** — 표 본문 행에만 20pt 허용
- **일반 색상 팔레트 사용 금지** — IBM Carbon Design System 색상만 사용
- **제목 가운데 정렬 금지** — IBM은 좌측 정렬 제목 사용
- **y=13.5" 아래에 콘텐츠 배치 금지** — 푸터 및 페이지 번호 영역
- **그라디언트 사용 금지** — IBM은 Carbon 단색만 사용
- **연속 슬라이드에 같은 IBM 템플릿 카테고리 반복 금지**

## PptxGenJS에서 흔히 하는 실수

- **같은 레이아웃 반복 금지** — 슬라이드 전체에서 IBM 템플릿 카테고리 다양하게 사용
- **본문 텍스트 가운데 정렬 금지** — 단락과 목록은 좌측 정렬
- **텍스트 박스 패딩 잊지 마십시오** — 텍스트 엣지와 도형을 정렬할 때 `margin: 0` 설정 또는 패딩을 고려한 도형 오프셋
- **저대비 요소 사용 금지** — 아이콘과 텍스트 모두 배경에 대해 충분한 대비 필요
- **제목 아래 강조선 절대 사용 금지** — AI 생성 슬라이드의 특징; 여백 또는 IBM 블루 강조 블록을 대신 사용
- **hex 색상에 "#" 절대 사용 금지** — PptxGenJS에서 파일 손상 발생
- **hex 문자열에 불투명도 인코딩 절대 금지** — 대신 `opacity` 속성 사용
- **createSlide()에서 async/await 절대 사용 금지** — compile.js가 await하지 않음
- **PptxGenJS 호출 간 옵션 오브젝트 재사용 절대 금지** — PptxGenJS가 오브젝트를 제자리에서 변경

---

## 치명적인 함정 — PptxGenJS

### createSlide()에서 async/await 절대 사용 금지

```javascript
// 잘못된 예 - compile.js가 await하지 않음
async function createSlide(pres, theme) { ... }

// 올바른 예
function createSlide(pres, theme) { ... }
```

### hex 색상에 "#" 절대 사용 금지

```javascript
color: "FF0000"      // 올바른 예
color: "#FF0000"     // 파일 손상
```

### hex 문자열에 불투명도 인코딩 절대 금지

```javascript
shadow: { color: "00000020" }              // 파일 손상
shadow: { color: "000000", opacity: 0.12 } // 올바른 예
```

### 제목의 텍스트 줄 바꿈 방지

```javascript
// 긴 제목에는 fit:'shrink' 사용
slide.addText("긴 제목 텍스트", {
  x: 0.5, y: 2, w: 9, h: 1,
  fontSize: 48, fit: "shrink"
});
```

### 호출 간 옵션 오브젝트 재사용 절대 금지

```javascript
// 잘못된 예
const shadow = { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 };
slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });
slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });

// 올바른 예 - 팩토리 함수 사용
const makeShadow = () => ({ type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 });
slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });
slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });
```
